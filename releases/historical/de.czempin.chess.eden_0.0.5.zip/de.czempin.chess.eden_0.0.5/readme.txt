Eden 0.0.5

Hello there!
Have fun with my chess engine "Eden".
Use a program like "Arena" (www.playwitharena.com) to play against it, or let other engines play against it
You can freely use it, but if you make money off it you have to ask me first, I might say yes.

Start it using "eden.bat" or configuring Arena to use that batch script.
Note that the script merely calls java to start the .jar file.
You need Java installed (tested with version 1.4) and in your path, for more info see http://java.sun.com


This is version 0.0.5

It has the following features:
- supports the very basics of the UCI protocol (for chess engines)
- knows all rules of chess, including castling and en passant
- can sub-promote if necessary, i. e. take a knight instead of a queen on promotion
- looks ahead three ply "brute force", just checking material and mates
- avoids stalemate if possible
- slightly varies its moves when they are otherwise equal (minimal random factor in the evaluation function)

The playing strength:
- play is similar to that of a typical beginner, so it makes a good practice opponent. The idea is to move up to the next higher version once you can consistently beat this one
- however it does actually play better than the typical beginner, because it never misses a hanging piece or a one-move mate
(perhaps I should make it a little more "human" in this respect

Limitations/Bugs/Future Features:
- doesn't avoid (or seek) three-repetitions draw
- doesn't avoid 50-moves draw
- can't force checkmate against the lonely king (although it sometimes happens by chance)
- UCI protocol not *fully* supported, in particular:
-- it does not support uci commands "while thinking" (asyncronously; it "thinks" so quickly that this doesn't matter for now)
-- no "debug" command
-- no "setoption" command (it doesn't have any options to set anyway)
-- the options to the "go" command are ignored
-- no "ponder" or "ponderhit" command
-- only "id", "uciok", "readyok" and "bestmove" (without "ponder") is sent back
- WB protocol not supported

Nicolai Czempin
eden@czempin.de

Changes since version 0.0.4:
- generalized the minimax search; it is now possible to give the search depth as a parameter (but it is currently hard-coded to 3)
- the time spent on each move gets irritatingly slow with ply > 3; therefore the next steps will be a little optimization
- removed the test positions for now, because I haven't updated them to the new playing strength