java -jar de.czempin.chess.eden_0.0.3.jar

