Eden 0.0.7, 2006-06-30


Hello there!
Have fun with my chess engine "Eden".
Use a program like "Arena" (www.playwitharena.com) to play against it, or let other engines play against it
You can freely use it, but if you make money off it you have to ask me first; I might even say yes.

Start it using "eden_0.0.7.bat" or configuring Arena to use that batch script.
Note that the script merely calls java to start the .jar file.
You need Java installed (tested with versions 1.4 and 1.5) and in your path, for more info see http://java.sun.com


This is version 0.0.7

It has the following features:
- supports the very basics of the UCI protocol (for chess engines)
- knows all rules of chess, including castling and en passant
- can sub-promote if necessary, i. e. take a knight instead of a queen on promotion
- looks ahead three ply "brute force", just checking material and mates
- avoids stalemate if possible

The playing strength:
- It plays similarly to an advanced beginner in the opening. It knows about very basic positional factors. Once it has secured a material advantage it does not know what to do with it.
- It managed a draw against its creator (Elo/DWZ ~1700-1800) in a 5-minute game where I underestimated it :-); in the next two games it got thorougly smashed :-)

Limitations/Bugs/Future Features:
- doesn't avoid (or seek) three-repetitions draw
- doesn't avoid 50-moves draw
- can't force checkmate against the lonely king (although it sometimes happens by chance)
- UCI protocol not *fully* supported, in particular:
-- it does not support uci commands "while thinking" (asynchronously; it "thinks" so quickly that this doesn't matter for now)
-- no "debug" command
-- no "setoption" command (it doesn't have any options to set anyway)
-- the options to the "go" command are ignored
-- no "ponder" or "ponderhit" command
-- only "id", "uciok", "readyok" and "bestmove" (without "ponder") is sent back
-- Needs to show the full "main line" again
- WB protocol not yet supported
- no transposition tables
- no null-move, pvs search
- very limited (and insufficient) evaluation function
- quite a bit of potential regarding general (non-chess-specific) performance improvement (for now, it was "naively" implemented in straightforward OO way, without regarding performance)

There is a compiled version of my previous engines on the Internet. Since it is much faster than the standard bytecode one, it will have different performance. For 0.0.6, with its
hard-coded search depth, this only makes a difference as to when games are lost on time. From version 0.0.7 on, I have implemented time control, and as such the compiled version
(for whose creation I give permission) will play differently.
*Please note this when/if setting up the compiled version in tournaments, by appending "(compiled)" to the name in results. The noncompiled version is intended to be the official version. *

Nicolai Czempin

I love feedback (criticism, questions, tournament reports, games played by Eden, ...)!
Email eden@czempin.de (very reluctantly I give here my "standard" email address: n.czempin@gmx.de)
I do lurk around the Arena forums from time to time (at the time of writing, http://f22.parsimony.net/forum41668/)

Changes from version 0.0.6 -> 0.0.7:
- Basic clock management; "wtime winc btime binc" are taken into account; search is interrupted when time per move too high
- Basic Iterative Deepening (not very efficient without a hash table!)
- Removed Feature: "slightly varies its moves when they are otherwise equal (minimal random factor in the evaluation function)"
- quiescence search has limit of iteration depth + 1 (not enough, but necessary for performance reasons for now)
- Basic move ordering
- Some bugs fixed, most notably 0.0.6 seemed to have trouble when it was close to being checkmated.
- some performance enhancements
- As overall result, version 0.0.7 is significantly stronger and more stable than 0.0.6
- I included two pictures that can be used (I hope that's okay with their creators; please step forward so I can credit you). I personally like the one with the "Eden" painting in the background. Submissions are always welcome!

Changes from version 0.0.5 -> 0.0.6:
- went from naive minimax to using alpha-beta 
- improved performance of move generation and board representation
- added quiescence search, which currently has a hard depth limit of 6 ply.
- more engine info is displayed as intended by the UCI protocol, such as search depth, the move currently being evaluated (and the number out of all the legal moves)
- Going from minimax to alpha-beta made the "Main Line" management much more complicated, so I temporarily dropped it. It will be back in a later release.

Changes from version 0.0.4 -> 0.0.5:
- generalized the minimax search; it is now possible to give the search depth as a parameter (but it is currently hard-coded to 3)
- the time spent on each move gets irritatingly slow with ply > 3; therefore the next steps will be a little optimization
- removed the test positions for now, because I haven't updated them to the new playing strength

Changes up to version 0.0.4:
- 0.0.4 was the first publically-released (and more or less usable) version.
