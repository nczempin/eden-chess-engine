java -jar de.czempin.chess.eden_0.0.7.jar
