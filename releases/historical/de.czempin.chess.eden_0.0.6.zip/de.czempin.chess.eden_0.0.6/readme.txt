Eden 0.0.6

Hello there!
Have fun with my chess engine "Eden". By itself, it is probably not very useful, unless you know the UCI protocol.
For a GUI, use a program like "Arena" (www.playwitharena.com) to play against it, or let other engines play against it.
You can freely use it, but if you make money off it you have to ask me first; I might even say yes.

Start it using "eden.bat" or configuring Arena to use that batch script.
Note that the script merely calls java to start the .jar file.
You need Java installed (tested with version 1.4) and in your path, for more info see http://java.sun.com.

Because the Fritz GUI doesn't support .bat files, Eden in this official release form won't work under the Fritz GUI. There is, however, a tool called "jlaunch" (not from me) which allows you to work around that restriction.

After the release, there will also probably be a compiled-to-native version (also not from me). However, this will not increase playing strength, it'll just make the same moves in less time.

This is version 0.0.6

It has the following features:
- supports the very basics of the UCI protocol (for chess engines)
- knows all rules of chess, including castling and en passant.
- can sub-promote if necessary, i. e. take a knight instead of a queen on promotion
- looks ahead three ply "brute force"
- position evaluation includes material and mates, as well as rudimentary positional factors
- avoids stalemate if possible/necessary.

The playing strength:
- play is similar to that of a typical advanced beginner, so it makes a good practice opponent. It can get through the opening without too much embarrassement, but then runs out of ideas. Interestingly, it makes the same kinds of positional mistakes my still-learning son makes, although he makes more tactical blunders. The idea is to move up to the next higher version once you can consistently beat this one.

Limitations/Bugs/Future Features:
- doesn't avoid (or seek) three-repetitions draw
- doesn't avoid (or seek) 50-moves draw
- doesn't seek to exchange pieces when ahead
- has no idea of how to attack or defend the king
- lots of other positional deficiencies
- UCI protocol not *fully* supported, in particular:
-- it does not support uci commands "while thinking" (asynchronously; it "thinks" so quickly that this doesn't matter for now; but it's getting "slower")
-- no "debug" command
-- no "setoption" command (it doesn't have any options to set anyway)
-- the options to the "go" command are ignored
-- no "ponder" or "ponderhit" command
-- only "id", "uciok", "readyok" and "bestmove" (without "ponder") is sent back
- WB protocol not supported
- search depth is fixed at 3 ply (+ 3 quiescence), so performance improvements (bei it by compiling the bytecode to native or by using a faster processor) will not improve skill. The next release will definitely change this part, I promise!
- Quiescence only includes captures, promotions and checks, but not threats by lower-valued pieces, which frequently get pushed over the horizon.
- There could be some kind of installer that checks for Java and/or a GUI.

Please send me your games, comments, suggestions, criticism, feature requests! Either use the comment feature of my weblog at www.czempin.de/nicolai/blog/ or send me an email: eden@czempin.de. I also tend loosely to follow the Support forum at the Arena website (www.playwitharena.com).

mfg
Nicolai Czempin

Changes from version 0.0.5 -> 0.0.6:
- went from naive minimax to using alpha-beta 
- improved performance of move generation and board representation
- added quiescence search, which currently has a hard depth limit of 6 ply.
- more engine info is displayed as intended by the UCI protocol, such as search depth, the move currently being evaluated (and the number out of all the legal moves)
- Going from minimax to alpha-beta made the "Main Line" management much more complicated, so I temporarily dropped it. It will be back in a later release.

Changes from version 0.0.4 -> 0.0.5:
- generalized the minimax search; it is now possible to give the search depth as a parameter (but it is currently hard-coded to 3)
- the time spent on each move gets irritatingly slow with ply > 3; therefore the next steps will be a little optimization
- removed the test positions for now, because I haven't updated them to the new playing strength

Changes up to version 0.0.4:
- 0.0.4 was the first publically-released (and more or less usable) version.